package br.edu.cs.poo.ac.seguro.mediators;

public class ValidadorCpfCnpj {
    public static boolean ehCnpjValido(String cnpj) {
        return false;
    }
    public static boolean ehCpfValido(String cpf) {
        return false;
    }
}
